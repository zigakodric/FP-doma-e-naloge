#Urejanje tabele
library(xts)
library(xtsExtra)
#Odstranjevanje odvečnih podatkov
Tabela2014 <- Tabela2014[,c(1,2,24,44,65,85,106,127,149,171,193,216,236)]
Tabela2015 <-Tabela2015[,c(1,2,23,43,65,85,105,127,150,171,193,215,236)]
Tabela2016 <- Tabela2016[,c(1,2,22,43,64,85,106,129,150,172,195,216,238)]

#Brisanje odvečnih podatkov
Tabela2014[,"X"] <- NULL
Tabela2015[,"X"] <- NULL
Tabela2016[,"X"] <- NULL
#Transformiranje tabel
transform(Tabela2014)
transform(Tabela2015)
transform(Tabela2016)

#Združitev tabel v eno
Tabela <- cbind(Tabela2014,Tabela2015,Tabela2016)

#Graf
TabelaGraf <- t(Tabela)
#Vektor z datumi
dates <- seq(as.Date("01/01/2014", format = "%d/%m/%Y"),
             by = "months", length = length(TabelaGraf[,5]))
plot(dates,TabelaGraf[,5],type="l",col="red", xlab ="Datum",ylab = "Stopnja Euriborja",main="Gibanje 3 in 6 mesečnega Euriborja")
lines(dates,TabelaGraf[,6],col="green")
#Legenda
legend("bottomleft", c("3 mesečni", "6 mesečni"),lty=c(1,1), col = c("red","green"), bg = "white", cex=0.9,)