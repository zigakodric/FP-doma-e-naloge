uvoziPodatke <- function() {
  return(read.csv("podatki/2016.csv",header = TRUE,quote = "\"", sep = ",", as.is = TRUE, na.strings = "..",fill=TRUE,
                  
                  fileEncoding = "Windows-1250"))
}

Tabela2016 <- uvoziPodatke()

uvoziPodatke5 <- function() {
  return(read.csv("podatki/2015.csv", sep = ",", as.is = TRUE, na.strings = "..",
                  fileEncoding = "Windows-1250"))
}

Tabela2015 <- uvoziPodatke5()

uvoziPodatke2 <- function() {
  return(read.csv("podatki/2014.csv", sep = ",", as.is = TRUE, na.strings = "..",
                  fileEncoding = "Windows-1250"))
}

Tabela2014 <- uvoziPodatke2()


