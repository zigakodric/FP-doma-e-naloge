#2 del naloge

#Izbira datumov
#Izbral sem si datume 1.10.2014, 3.8.2015 in 1.2.2016

#Preureditev tabel v vektorje
cas2014<- c()
cas2015 <-c()
cas2016 <-c()
for (i in 1:8) 
  cas2014[i] <-Tabela2014[i,10]

for (i in 1:8) 
  cas2015[i] <-Tabela2015[i,8]

for (i in 1:8) 
  cas2016[i] <-Tabela2016[i,2]

x<-c(0.25,0.5,1,2,3,6,8,12)
#Graf


matplot(x,cbind(cas2014,cas2015,cas2016),type="l", col=c("red","blue","green"), xlab="Dospetje[mesec]",ylab="%", main="Časovna struktura obrestnih mer")
legend("topleft",c("1.10.2014","3.8.2015","1.2.2016"), lty=c(1,1,1), col=c("red","blue","green"))

#Oblike krivulj strukture obrestnih mer je "normalna", obresti se torej zvišujejo z višjim
#časom dospetja.