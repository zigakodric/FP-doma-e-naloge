#Tretji del naloge

#vektor z vrednostmi 3 mesečne vrednosti Euriborja
tri <- c()
for (i in 1:length(Tabela[5,]))
  tri[i] <- Tabela[5,i]

#vektor z vrednostmi 6 mesečne obrestne mere
sest <- c()
for (i in 1:length(Tabela[6,]))
  sest[i] <- Tabela[6,i]

#Vektor z napovedanimi vrednostmi terminske obrestne mere L(0,3,6)
terminska <- c()

#Zanka za izračun napovedanih vrednosti
for (i in 1:length(tri))
  terminska[i]<- 1/(6/12-3/12)*(((1+sest[i]*6/12)/(1+tri[i]*3/12))-1)

#Poprava vektorja terminskih obrestnih mer, da bo primeren za našo tabelo
ter <- c()
ter[1] <- NA
ter[2] <- NA
ter[3] <- NA

for (i in 4:36)
  ter[i] <- terminska[i]

#Tabela primerjav napovedi obrestnih mer in dejanskih

prim <- matrix(nrow=36,ncol=3)
for (i in 1:36)
  prim[i,1] <- tri[i]

for (i in 1:36)
  prim[i,2]<-sest[i]

for (i in 1:36)
  prim[i,3]<-ter[i]

#Tabele z napovedanimi vrednostmi 4m Euriborja za vsako leto

nap2014 <- matrix(nrow=10,ncol=1)
nap2015 <- matrix(nrow=12,ncol=1)
nap2016 <- matrix(nrow=12,ncol=1)

for (i in 4:12)
  nap2014[i] <- ter[i]

for (i in 13:24)
  nap2015[i-12] <- ter[i]

for (i in 25:36)
  nap2016[i-24] <- ter[i]

#Tabele z dejanskimi 4m obrestnimi merami
dej2014 <- matrix(nrow=10,ncol=1)
dej2015 <- matrix(nrow=12,ncol=1)
dej2016 <- matrix(nrow=12,ncol=1)

for (i in 4:12)
  dej2014[i] <- tri[i]

for (i in 13:24)
  dej2015[i-12] <- tri[i]

for (i in 25:36)
  dej2016[i-24] <- tri[i]

#Graf z napovedmi/dejanskimi obrestnimi merami
#Regresijska premica
reg <- lm(prim[,3]~prim[,1])
plot(prim[,1],prim[,3], col=c("blue","red","green"),asp=1, xlim=c(-0.5,0.5), ylab="Napoved",xlab="Opazovano")
abline(a=0,b=1)
abline(reg, col="purple")
legend("bottomleft",c("2014", "2015","2016","Simetrala", "Prileganje"),lty=c(1,1,1,1,1), col = c("blue","red","green","Black","purple"), bg = "white", cex=0.9,)

#Graf za leto 2014
reg1 <- lm(nap2014~dej2014)
plot(dej2014,nap2014, col="red",asp=1, xlab="Opazovano",ylab="Napoved")
abline(a=0,b=1)
abline(reg1,col="blue")
legend("bottomleft",c("Leto 2014","Simetrala","Regresija"),lty=c(1,1,1), col=c("red","black","blue"), bg="white",cex=0.9)

#Graf za leto 2015
reg2 <- lm(nap2015~dej2015)
plot(dej2015,nap2015, col="red",asp=1, xlab="Opazovano",ylab="Napoved")
abline(a=0,b=1)
abline(reg2,col="blue")
legend("bottomleft",c("Leto 2015","Simetrala","Regresija"),lty=c(1,1,1), col=c("red","black","blue"), bg="white",cex=0.9)

#Graf za leto 2016
reg3 <- lm(nap2016~dej2016)
plot(dej2016,nap2016, col="red",asp=1, xlab="Opazovano",ylab="Napoved")
abline(a=0,b=1)
abline(reg3,col="blue")
legend("bottomleft",c("Leto 2016","Simetrala","Regresija"),lty=c(1,1,1), col=c("red","black","blue"), bg="white",cex=0.9)

#Empirični podatki ne potrjujejo hipoteze. Res je, da so leta 0d 2014-2016 netipična,
#saj so v tem času obrestne mere zaradi ukrepov centralnih bank dosegle cele negativne 
#vrednosti. Tako, da ta leta niso najbolj primerna za potrjevanje hipoteze v splošnem.