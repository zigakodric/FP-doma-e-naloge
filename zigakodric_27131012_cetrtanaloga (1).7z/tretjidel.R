#tretji del

EG <- function(vrsta,alpha){
  zgvr <- c()
  zgvr[1] <- vrsta[1]
  dol <- as.numeric(length(vrsta))
  for(i in 2:dol)
    zgvr[i] <- alpha*vrsta[i]+(1-alpha)*zgvr[i-1]
  return(zgvr)
}
zg <- ts(EG(Podatki,0.3))
ts.plot(glas, zg, col = c("black","red"))

#Napoved za naslednji dan

nasd <- 0.3*Podatki[80]+(1-0.3)*zg[80]
#Iskanje optimalnega aplhe

opti <- function(alpha){
  vsota <- c()
  dol <- as.numeric(length(Podatki))
  zr <- EG(Podatki, alpha)
  for(i in 1:(dol-1))
    vsota[i] <- (Podatki[i+1]-zr[i])
  return(sum(vsota)/(dol-1))
}

min <- as.numeric(optimize(opti,c(0,1))[1])

naj <- ts(EG(Podatki,min))

ts.plot(naj, pods, col = c("green", "blue"))

#napoved
napnaj <- Podatki[80]*min+(1-min)*naj[80]