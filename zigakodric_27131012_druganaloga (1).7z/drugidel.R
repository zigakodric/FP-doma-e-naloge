#Drugi del
#Diskretizacija porazdelitve Y
diskrety <- discretize(pexp(x, rate),0,10, step = 0.5, method = "rounding")

#Graf porazdelitvene funkcije Y in njene diskretizacije
dis <- ecdf(diskrety)
plot(dis)
curve(pexp(x,0.9436157),add = TRUE, col = "red")


#Panerjev algoritem
S <- aggregateDist(methode = "recursive", model.sev=diskrety, model.freq="poisson", lambda = 15, x.scale=0.5,maxit=1000000,tol=0.005,is.atomic=TRUE)

#Upanje in disperzija
summary(S)
skoki <- knots(S)
S(skoki)
mean(S)
#Pričakovan izpad in tvegana vrednost
tvegana <- VaR(S,0.995)
izpad <- CTE(S,0.005)