#tretji del

#simulacija N-ja
sN <- rpois(10000,15)

#simulacija Y
sY <- c()
for (i in 1:10000)
  sY[i] <- sum(rexp(sN[i],rate))

#Porazdelitvena funkcija
poraz <- ecdf(sY)

#Upanje in disperzija
upanje <-mean(sY)
disperzija <- var(sY)


#Tvegana vrednost
tvegana2 <- quantile(poraz,0.995)

#graf
plot(S)
plot(poraz, col = "red", add=TRUE)
legend("bottomright", c("Panerjev","Monte Carlo"), lty = c(1,1), col=c("black","red"))