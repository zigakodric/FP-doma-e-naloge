#Uvoz Podatkov

Podatki <-read.table("podatki/vzorec2.txt",header = TRUE,quote = "\"", sep = ",", as.is = TRUE, na.strings = "..",fill=TRUE,
          
          fileEncoding = "Windows-1250")

#Histogram
#Spremenimo podatke v numerične
Podatki <- as.numeric(Podatki$X0.211933)
hist(Podatki, xlab="Višina odškodnine", main="Histogram")

#Eksponentna
library(actuar)

ocena <- mde(Podatki,pexp, start=list(rate=1), measure="CvM")

#Dodajanje krivulje na histogram
hist(Podatki, xlab="Višina odškodnine", main="Histogram", prob = TRUE, col = "blue")
curve(dexp(x,rate=0.9436157), add = TRUE, col = "red")

#Vzorčna in teoretična porazdelitvena funkcija
plot(ecdf(Podatki), col="blue", ylab="porazdelitvena funckija", xlab = "višina odškodnine", main="Porazdelitvena funckija odškodnin")
curve(pexp(x,0.9436157),add = TRUE, col = "red")

#Upanje in disperzija z Waldovimi identitetami
rate <- 0.9436157 
lambda <- 15
EY <- 1/rate
VARY <- 1/(rate)^2
EN <- lambda
EY2 <- EY*EY
VARN <- lambda

ES <- EN * EY
VARS <- VARY*EN+EY2*VARN