#Prvi del

#Matrika Poti
a1 = c(50,52.5,49.88) 
a11 =c(52.37,49.75,52.24)
a2 = c(50,52.5,55.12)
a22=c(57.88,60.78,63.81)
a3 = c(50,47.5,49.88)
a33=c(47.38,45.01,42.76)
a4 = c(50,47.5,45.12)
a44 =c(47.38,49.75,52.24)
a5 = c(50,52.5,49.88)
a55 =c(52.37,54.99,57.74)

Poti1 <- matrix(c(a1,a2,a3,a4,a5), nrow = length(a1))
Poti1 <- t(Poti1)
Poti2 <- matrix(c(a11,a22,a33,a44,a55), nrow = length(a11))
Poti2 <- t(Poti2)
#Izplačilo nakupnega
izplačilanak <- c()
for (i in 1:5)
  izplačilanak[i] <- max(Poti2[i,])-max(Poti1[i,])


#Izplačila prodanjega
izplačilaprod <- c()
for (i in 1:5)
  izplačilaprod[i] <- min(Poti2[i,])-min(Poti1[i,])


izplacilo <- function(vrsta,T,type){
  U <- as.numeric(length(vrsta))
  T <- as.numeric(T)
  max_nak_T <- max(vrsta[1:T])
  max_nak_U <- max(vrsta[T+1:(U-T)])
  min_prod_T <- min(vrsta[1:T])
  min_prod_U <- min(vrsta[T+1:(U-T)])
  if (type =="call")
    if (max_nak_U-max_nak_T < 0)
      return(0)
  else
    return(max_nak_U-max_nak_T)
  else
    if (min_prod_U-min_prod_T < 0)
      return(0)
  else
    return(min_prod_U-min_prod_T)
}

