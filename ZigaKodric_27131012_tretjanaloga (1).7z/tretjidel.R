#tretjidel
S0=60
s0= 60
u = 1.05
d = 0.95
T = 8
type = "put"
U = 15
R = 0.01
N1 <-10
N2 <- 100
N3 <- 1000

m1 <- c()
m2 <- c()
m3 <- c()
for (i in 1:100)
  m1[i] <- monte(S0,u,d,U,R,T,type,N1)
hist(m1)

for (i in 1:100)
  m2[i] <- monte(S0,u,d,U,R,T,type,N2)
hist(m2)

for (i in 1:1000)
  m3[i] <- monte(S0,u,d,U,R,T,type,N3)
hist(m3)

#Povprečne ocene
pov1 <-mean(m1)
pov2 <-mean(m2)
pov3 <- mean(m3)

#primerjava z oceno binomskega
bin <- binomski(s0, u, d, U,R,T,type)
pov1 - bin
pov2 - bin
pov3 - bin

#standardni odklon
st1 <- sd(m1)
st2 <- sd(m2)
st3 <- sd(m3)
#dodajanje ocen
hist(m1)
abline(v =pov1, col = "red")
arrows(x0 = pov1, y0 =0 ,x1 = pov1+st1, y1 = 0, col = "red")
arrows(x0 = pov1, y0 =0 ,x1 = pov1-st1, y1 = 0, col = "red")



hist(m2)
arrows(x0 = pov2, y0 =0 ,x1 = pov2+st2, y1 = 0, col = "red")
arrows(x0 = pov2, y0 =0 ,x1 = pov2-st2, y1 = 0, col = "red")
abline(v = pov2, col = "green")

hist(m3)
abline( v=pov3, col = "blue")
arrows(x0 = pov3, y0 =0 ,x1 = pov3+st3, y1 = 0, col = "red")
arrows(x0 = pov3, y0 =0 ,x1 = pov3-st3, y1 = 0, col = "red")
