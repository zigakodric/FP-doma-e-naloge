library(Rlab)
library(combinat)
binomski <- function(s0, u, d, U,R,T,type) {
  kocka <- hcube(rep(2,U),translation =-1)
  S0 <- s0
  verjetnosti <- c()
  ver <- (1+R-d)/(u-d)
  vsota <- rowSums(kocka)
  vektorverj <- ((1-ver)^(U-vsota))*(ver^vsota)
  vek <- c()
  for (i in length(vektorverj):1)
    vek[length(vektorverj)-i+1] <- vektorverj[i]
  izplacila <- d*kocka + u*(1-kocka)
  zacetna <- rep(s0,nrow(kocka))
  bin <- cbind(zacetna, izplacila)
  d <-t(apply(bin,1, cumprod))
  izpla <- c()
  for (i in 1:nrow(kocka))
    izpla[i] <- izplacilo(d[i,],T,type)
  izpla <- t(izpla)
  konc <- izpla*vek
  EX <- sum(konc)
  return(EX/(1+R)^U)
}

monte <- function(S0,u,d,U,R,T,type,N){
  ver1 <- (1+R-d)/(u-d)
  #simulacija poti
  matrikapo <- matrix(0,N,U)
  for (i in 1:U)
    matrikapo[,i] <-(rbinom(N,1,1-ver1))
  
  #Izplačila
  zac <- rep(S0,N)
  matrikapo <- d*matrikapo + u*(1-matrikapo)
  mat <- cbind(zac,matrikapo)
  m <- t(apply(mat,1,cumprod))
  izplacilam <- c()
  for (i in 1:N)
    izplacilam[i] <- izplacilo(m[i,], T, type)
  rezultat <- sum(izplacilam)/N
  return(rezultat/((1+R)^U))
}