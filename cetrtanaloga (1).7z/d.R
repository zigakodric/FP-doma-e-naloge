vrsta <- Podatki
k <- 7
vsota <- 0
glajena <- gla
dol <- as.numeric(length(vrsta))
for(i in (k+2):(dol-1))
  vsota[i-k-2] <- (vrsta[i+1]-glajena[i+1])^2
sum(vsota)/(dol-k)