#Prvi del
#Uvoz podatkov

Podatki <- read.csv("zlato.csv", na.strings = "..",
                    fileEncoding = "Windows-1250")

#Zmanj�amo �tevilo podatkov, izberemo samo eno valuto

Podatki <- Podatki[,7]
Podatki <- Podatki[1:80]

#Obrnemo podatki
for(i in 80:1)
  Podatki[81-i] <- Podatki[i]

#Graf

plot(Podatki, type = "l", main = "zlato")