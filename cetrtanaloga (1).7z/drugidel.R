#Drugi del
#Funkcija

G <- function(vrsta,k){
  glajena <- c()
  dolzina <- as.numeric(length(vrsta))
  for(i in 1:(k-1))
    glajena[i] <- NA
  for(i in (k):dolzina)
    glajena[i+1] <- sum(vrsta[(i-k+1):i])/k
  return(glajena)
}


#Glajenje reda 7
gla <- G(Podatki,7)

#Napoved za naslednji dan
nas <- sum(gla[(80-7+1):80])/7

#Graf
glas <- ts(gla)
pods <- ts(Podatki)

ts.plot(pods, glas, col = c("black","red"))


#Srednja kvadratna napaka
MSE <- function(vrsta,glajena,k){
  vsota <- 0
  dol <- as.numeric(length(vrsta))
  for(i in (k+2):(dol-1))
    vsota[i-k-2] <- (vrsta[i+1]-glajena[i+1])^2
  return(sum(vsota)/(dol-k))
}
mse7 <- MSE(Podatki, gla,7)

#Red glajenja 14
gla14 <- G(Podatki,14)
mse14 <- MSE(Podatki,glajena,14)

gla14s <- ts(gla14)

ts.plot(gla14s, pods, col=c("red", "black"))

#Red glajenja 30
gla30 <- G(Podatki,30)
mse30 <- MSE(Podatki, glajena,30)
